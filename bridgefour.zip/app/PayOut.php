<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayOut extends Model
{
    protected $guarded = [];
}
